(function(){
  const file=document.getElementById('sourceFile'),label=document.getElementById('fileLabel');
  if(file&&label) file.addEventListener('change',()=>{
    const name=file.files?.[0]?.name||'';label.textContent=name||'اختر ملفاً أو ZIP';
    if(name.toLowerCase().endsWith('.php')){
      const entry=document.querySelector('input[name="entrypoint"]');
      const mode=document.querySelector('select[name="php_runtime_mode"]');
      if(entry) entry.value=name;
      if(mode) mode.value='auto';
    }
  });

  window.clearConsole=function(){const c=document.getElementById('console');if(c)c.innerHTML='';};

  function fmtDuration(sec){
    sec=Math.max(0,Math.floor(Number(sec)||0));
    const d=Math.floor(sec/86400);sec%=86400;const h=Math.floor(sec/3600);sec%=3600;const m=Math.floor(sec/60);const s=sec%60;
    return (d?d+'ي ':'')+(h?String(h).padStart(2,'0')+':':'')+String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');
  }
  function setText(id,v){const e=document.getElementById(id);if(e)e.textContent=v;}
  function setBar(id,v){const e=document.getElementById(id);if(e)e.style.width=Math.max(0,Math.min(100,Number(v)||0))+'%';}

  async function pollSystem(){
    if(!window.XM_DASHBOARD)return;
    try{
      const r=await fetch('/api/system',{cache:'no-store'}); if(!r.ok)return; const s=await r.json();
      setText('sysCpu',s.cpu_percent.toFixed(1)+'%');setBar('sysCpuBar',s.cpu_percent);
      setText('sysRam',s.memory_percent.toFixed(1)+'%');setBar('sysRamBar',s.memory_percent);setText('sysRamUsed',Math.round(s.memory_used_mb));
      setText('sysDisk',s.disk_percent.toFixed(1)+'%');setBar('sysDiskBar',s.disk_percent);setText('sysRunning',s.running_projects);
    }catch(e){}
  }
  if(window.XM_DASHBOARD){pollSystem();setInterval(pollSystem,2500);}

  const projectId=window.XM_PROJECT_ID;
  const consoleEl=document.getElementById('console');
  if(consoleEl&&projectId){
    let last=0; consoleEl.querySelectorAll('.log-line').forEach(x=>last=Math.max(last,Number(x.dataset.id)||0));
    const es=new EventSource(`/projects/${projectId}/events?after=${last}`);
    es.onmessage=(ev)=>{
      const row=JSON.parse(ev.data);last=Math.max(last,Number(row.id)||0);
      const d=document.createElement('div');d.className='log-line '+(row.level||'info');d.dataset.id=row.id;
      const time=(row.created_at||'').slice(11,19);
      d.innerHTML=`<time>${escapeHtml(time)}</time><span class="tag">${escapeHtml(row.stage||'system')}</span><pre>${escapeHtml(row.message||'')}</pre>`;
      consoleEl.appendChild(d);while(consoleEl.children.length>800)consoleEl.firstElementChild.remove();consoleEl.scrollTop=consoleEl.scrollHeight;
      setText('logCount',consoleEl.children.length+' lines');
    };
    es.onopen=()=>setText('streamState','● متصل بالسجل');
    es.onerror=()=>setText('streamState','● إعادة الاتصال...');
  }

  function escapeHtml(s){const d=document.createElement('div');d.textContent=String(s);return d.innerHTML;}

  let ramPoints=(window.XM_INITIAL_METRICS||[]).map(x=>Number(x.memory_mb)||0);
  function drawChart(){
    const c=document.getElementById('ramChart');if(!c)return;const ctx=c.getContext('2d');const w=c.width,h=c.height;ctx.clearRect(0,0,w,h);
    const pts=ramPoints.slice(-60);if(pts.length<2)return;const max=Math.max(1,...pts);ctx.beginPath();pts.forEach((v,i)=>{const x=i/(pts.length-1)*w;const y=h-(v/max)*(h-6)-3;i?ctx.lineTo(x,y):ctx.moveTo(x,y)});ctx.strokeStyle='#49d6ff';ctx.lineWidth=2;ctx.stroke();
  }
  drawChart();

  async function pollProject(){
    if(!projectId)return;
    try{
      const r=await fetch(`/api/projects/${projectId}/stats`,{cache:'no-store'});if(!r.ok)return;const data=await r.json(),p=data.project;
      setText('cpuValue',(Number(p.cpu_percent)||0).toFixed(1)+'%');
      setText('ramValue',(Number(p.memory_mb)||0).toFixed(1)+' MB');setText('ramPct',(Number(p.memory_percent)||0).toFixed(2)+'% من الخادم');
      setText('readValue',Number(p.read_mb||0).toFixed(1));setText('writeValue',Number(p.write_mb||0).toFixed(1));setText('diskValue',Number(p.disk_mb||0).toFixed(1));setText('threadValue',p.threads||0);setText('processValue',p.processes||0);setText('guardStateValue',p.guard_state||'طبيعي');
      setText('restartValue',p.restart_count||0);setText('crashValue',p.crash_count||0);setText('healthValue',(p.health_score||0)+'%');setText('stabilityValue',p.stability||'—');setText('pidValue',p.pid||'—');setText('dependencyValue',p.dependency_status||'—');setText('exitValue',p.exit_code===null||p.exit_code===undefined?'—':p.exit_code);setText('deployValue',p.deploy_count||0);
      setText('uptimeValue',fmtDuration(p.uptime_seconds||0));
      if(p.last_heartbeat)setText('heartbeatValue','Heartbeat: '+String(p.last_heartbeat).slice(11,19));
      const st=document.getElementById('liveStatus');if(st){st.className='status big '+(p.status||'');st.innerHTML='<i></i>'+escapeHtml(p.status||'—');}
      const radial=document.getElementById('cpuRadial');if(radial)radial.style.setProperty('--p',Math.min(100,Number(p.cpu_percent)||0));
      ramPoints=(data.history||[]).map(x=>Number(x.memory_mb)||0);drawChart();
    }catch(e){}
  }
  if(projectId){pollProject();setInterval(pollProject,2000);}
})();

// ========================= V5 notification center =========================
(function(){
  const bell=document.getElementById('notificationBell');
  const pop=document.getElementById('notificationPopover');
  const items=document.getElementById('notificationItems');
  const badge=document.getElementById('notificationBadge');
  if(!bell||!pop||!items)return;
  const iconMap={success:'✓',error:'!',warning:'⚠',runtime:'▶',repair:'⌁',files:'▤',github:'◉',support:'🛟',announcement:'📣',delete:'⌫',welcome:'✦',account:'👤',project:'Py',admin_message:'💬'};
  const esc=(v)=>{const d=document.createElement('div');d.textContent=String(v??'');return d.innerHTML};
  async function loadNotifications(){
    try{
      const r=await fetch('/api/notifications',{cache:'no-store'}); if(!r.ok)return;
      const data=await r.json();
      const unread=Number(data.unread||0);
      badge.textContent=unread>99?'99+':unread;
      badge.classList.toggle('hidden',unread<1);
      const rows=data.items||[];
      items.innerHTML=rows.length?rows.map(n=>`<a class="notify-mini ${esc(n.kind)} ${Number(n.is_read)?'':'unread'}" href="/notifications/${Number(n.id)}/go"><span class="notify-mini-icon">${esc(iconMap[n.kind]||'🔔')}</span><div><b>${esc(n.title)}</b><p>${esc(n.message||'')}</p></div><small>${esc(String(n.created_at||'').slice(11,16))}</small></a>`).join(''):'<div class="notification-empty">لا توجد إشعارات جديدة.</div>';
    }catch(e){}
  }
  bell.addEventListener('click',(e)=>{e.stopPropagation();pop.classList.toggle('open');if(pop.classList.contains('open'))loadNotifications();});
  document.addEventListener('click',(e)=>{if(!pop.contains(e.target)&&e.target!==bell)pop.classList.remove('open');});
  loadNotifications(); setInterval(loadNotifications,7000);
})();

// ========================= V12.5 logout confirmation =========================
(function(){
  const modal=document.getElementById('logoutModal');
  const trigger=document.getElementById('logoutTrigger');
  const cancel=document.getElementById('logoutCancel');
  const confirm=document.getElementById('logoutConfirm');
  const form=document.getElementById('logoutForm');
  if(!modal||!trigger||!form)return;
  const open=()=>{modal.classList.remove('hidden');document.body.style.overflow='hidden';setTimeout(()=>cancel?.focus(),0)};
  const close=()=>{modal.classList.add('hidden');document.body.style.overflow='';trigger.focus()};
  trigger.addEventListener('click',open);
  cancel?.addEventListener('click',close);
  confirm?.addEventListener('click',()=>{confirm.disabled=true;confirm.textContent='جارٍ تسجيل الخروج...';form.submit()});
  modal.addEventListener('click',e=>{if(e.target===modal)close()});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!modal.classList.contains('hidden'))close()});
})();
